// app.js — Quote of the Day App Logic

let currentIndex = 0;
let favorites = [];

// ---- Initialization ----

function init() {
  // Display today's date
  const d = new Date();
  document.getElementById('date-badge').textContent = d.toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric'
  });

  // Load saved favorites from localStorage
  try {
    favorites = JSON.parse(localStorage.getItem('qotd_favorites') || '[]');
  } catch (e) {
    favorites = [];
  }

  // Pick today's quote based on date seed
  currentIndex = getTodayIndex();

  buildDots();
  showQuote(currentIndex);

  // Show native share button if supported
  if (navigator.share) {
    document.getElementById('native-share').style.display = 'flex';
  }
}

// ---- Quote Selection ----

function getTodayIndex() {
  const d = new Date();
  const seed = d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
  return seed % QUOTES.length;
}

function showQuote(index) {
  const q = QUOTES[index];
  document.getElementById('quote-text').textContent = q.text;
  document.getElementById('quote-author').textContent = '— ' + q.author;
  document.getElementById('quote-category').textContent = q.cat;

  // Update favorite button state
  const isFav = favorites.some(f => f.text === q.text);
  const favBtn = document.getElementById('fav-btn');
  favBtn.className = 'btn' + (isFav ? ' favorited' : '');
  favBtn.innerHTML = isFav
    ? '<i class="ti ti-heart"></i> Saved'
    : '<i class="ti ti-heart"></i> Save';

  // Update active dot
  document.querySelectorAll('.dot').forEach((dot, i) => {
    dot.classList.toggle('active', i === index);
  });
}

function nextQuote() {
  goTo((currentIndex + 1) % QUOTES.length);
}

function goTo(index) {
  currentIndex = index;
  const card = document.getElementById('quote-card');
  card.classList.add('fading');
  setTimeout(() => {
    showQuote(index);
    card.classList.remove('fading');
  }, 300);
}

// ---- Dot Navigation ----

function buildDots() {
  const container = document.getElementById('dots');
  container.innerHTML = '';
  QUOTES.forEach((_, i) => {
    const dot = document.createElement('span');
    dot.className = 'dot' + (i === currentIndex ? ' active' : '');
    dot.setAttribute('aria-label', 'Quote ' + (i + 1));
    dot.addEventListener('click', () => goTo(i));
    container.appendChild(dot);
  });
}

// ---- Favorites ----

function toggleFavorite() {
  const q = QUOTES[currentIndex];
  const idx = favorites.findIndex(f => f.text === q.text);

  if (idx >= 0) {
    favorites.splice(idx, 1);
    showToast('Removed from favorites');
  } else {
    favorites.push(q);
    showToast('Saved to favorites!');
  }

  // Persist to localStorage
  try {
    localStorage.setItem('qotd_favorites', JSON.stringify(favorites));
  } catch (e) {
    console.warn('localStorage unavailable');
  }

  showQuote(currentIndex);
}

function renderFavs() {
  const list = document.getElementById('favs-list');

  if (!favorites.length) {
    list.innerHTML = `
      <p class="empty-favs">
        <i class="ti ti-heart"></i><br>
        No saved quotes yet.<br>
        Tap Save on a quote you love.
      </p>`;
    return;
  }

  list.innerHTML = '';
  favorites.forEach((q, i) => {
    const item = document.createElement('div');
    item.className = 'fav-item';
    item.innerHTML = `
      <div>
        <p class="fav-text">${escapeHtml(q.text)}</p>
        <p class="fav-author">— ${escapeHtml(q.author)}</p>
      </div>
      <span class="fav-remove" title="Remove" onclick="removeFav(${i})">
        <i class="ti ti-x"></i>
      </span>`;
    list.appendChild(item);
  });
}

function removeFav(index) {
  favorites.splice(index, 1);
  try {
    localStorage.setItem('qotd_favorites', JSON.stringify(favorites));
  } catch (e) {}
  renderFavs();
  showQuote(currentIndex);
  showToast('Removed from favorites');
}

// ---- Share ----

function toggleShare() {
  const panel = document.getElementById('share-panel');
  panel.classList.toggle('open');
}

function copyQuote() {
  const q = QUOTES[currentIndex];
  const text = `"${q.text}" — ${q.author}`;
  navigator.clipboard.writeText(text)
    .then(() => showToast('Quote copied!'))
    .catch(() => showToast('Copy failed'));
}

function shareVia(platform) {
  const q = QUOTES[currentIndex];
  const text = `"${q.text}" — ${q.author}`;

  if (platform === 'twitter') {
    const url = 'https://twitter.com/intent/tweet?text=' + encodeURIComponent(text);
    window.open(url, '_blank');
  } else if (platform === 'whatsapp') {
    const url = 'https://wa.me/?text=' + encodeURIComponent(text);
    window.open(url, '_blank');
  } else if (platform === 'native' && navigator.share) {
    navigator.share({ title: 'Quote of the Day', text }).catch(() => {});
  }
}

// ---- Tab Navigation ----

function switchTab(tab, btn) {
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-' + tab).classList.add('active');
  btn.classList.add('active');
  if (tab === 'favs') renderFavs();
}

// ---- Toast Notification ----

function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2200);
}

// ---- Utility ----

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ---- Start App ----
init();
