# Quote of the Day App

A clean, responsive web app that displays a new inspiring quote every day with favorites and sharing features.

## Files

| File | Purpose |
|------|---------|
| `index.html` | App structure and markup |
| `style.css` | All styles (light + dark mode) |
| `quotes.js` | Quote data (20 quotes) |
| `app.js` | App logic — navigation, favorites, sharing |

## Features

- **Daily Quote** — Automatically picks a quote based on today's date (consistent all day, changes tomorrow)
- **Browse Quotes** — Tap "New" or the dot indicators to browse all quotes
- **Favorites** — Save quotes to a persistent favorites list (stored in localStorage)
- **Share** — Copy to clipboard, share to Twitter/X, WhatsApp, or native share sheet
- **Dark Mode** — Automatically adapts to system preference

## How to Run

Just open `index.html` in any modern browser — no build tools or server required.

```bash
open index.html
```

Or serve locally:

```bash
npx serve .
# or
python3 -m http.server 8000
```

## Adding More Quotes

Open `quotes.js` and add objects to the `QUOTES` array:

```js
{ text: "Your quote here.", author: "Author Name", cat: "Category" },
```

## Browser Support

Works in all modern browsers (Chrome, Firefox, Safari, Edge). Native share requires a mobile browser that supports the Web Share API.
