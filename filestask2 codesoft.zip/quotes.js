// quotes.js — Quote data for Quote of the Day App

const QUOTES = [
  { text: "The only way to do great work is to love what you do.", author: "Steve Jobs", cat: "Work" },
  { text: "In the middle of every difficulty lies opportunity.", author: "Albert Einstein", cat: "Resilience" },
  { text: "It does not matter how slowly you go, as long as you do not stop.", author: "Confucius", cat: "Persistence" },
  { text: "Life is what happens when you're busy making other plans.", author: "John Lennon", cat: "Life" },
  { text: "The future belongs to those who believe in the beauty of their dreams.", author: "Eleanor Roosevelt", cat: "Dreams" },
  { text: "Success is not final, failure is not fatal — it is the courage to continue that counts.", author: "Winston Churchill", cat: "Courage" },
  { text: "Happiness is not something ready-made. It comes from your own actions.", author: "Dalai Lama", cat: "Happiness" },
  { text: "The only impossible journey is the one you never begin.", author: "Tony Robbins", cat: "Action" },
  { text: "You miss 100% of the shots you don't take.", author: "Wayne Gretzky", cat: "Action" },
  { text: "Whether you think you can or you think you can't, you're right.", author: "Henry Ford", cat: "Mindset" },
  { text: "Believe you can and you're halfway there.", author: "Theodore Roosevelt", cat: "Mindset" },
  { text: "Start where you are. Use what you have. Do what you can.", author: "Arthur Ashe", cat: "Action" },
  { text: "Everything you've ever wanted is on the other side of fear.", author: "George Addair", cat: "Courage" },
  { text: "Do one thing every day that scares you.", author: "Eleanor Roosevelt", cat: "Growth" },
  { text: "The best time to plant a tree was 20 years ago. The second best time is now.", author: "Chinese Proverb", cat: "Wisdom" },
  { text: "Your time is limited, so don't waste it living someone else's life.", author: "Steve Jobs", cat: "Life" },
  { text: "The secret of getting ahead is getting started.", author: "Mark Twain", cat: "Action" },
  { text: "It always seems impossible until it's done.", author: "Nelson Mandela", cat: "Resilience" },
  { text: "Dream big and dare to fail.", author: "Norman Vaughan", cat: "Dreams" },
  { text: "Keep your face always toward the sunshine, and shadows will fall behind you.", author: "Walt Whitman", cat: "Happiness" },
];
