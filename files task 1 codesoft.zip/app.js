// ── TASKFLOW APP — app.js ──────────────────────────────────────────────────────

const STORAGE_KEY = 'taskflow_tasks_v2';

let state = {
  tasks: [],
  view: 'all',      // all | active | completed | high | today
  filter: 'all',   // all | low | medium | high
  search: '',
  editId: null,
  deleteId: null,
};

// ── STORAGE ───────────────────────────────────────────────────────────────────

function loadTasks() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) state.tasks = JSON.parse(raw);
  } catch(e) {}
  if (!state.tasks.length) {
    state.tasks = [
      { id: uid(), title: 'Design system wireframes', desc: 'Create low-fidelity mockups for the dashboard.', priority: 'high', due: today(1), done: false, created: Date.now() },
      { id: uid(), title: 'Review pull requests', desc: '', priority: 'medium', due: today(0), done: false, created: Date.now()-1000 },
      { id: uid(), title: 'Update project README', desc: 'Add setup instructions and contribution guide.', priority: 'low', due: today(3), done: true, created: Date.now()-2000 },
      { id: uid(), title: 'Sprint planning meeting', desc: 'Prepare agenda and velocity metrics.', priority: 'high', due: today(-1), done: false, created: Date.now()-3000 },
    ];
    saveTasks();
  }
}

function saveTasks() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state.tasks));
}

// ── HELPERS ───────────────────────────────────────────────────────────────────

function uid() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

function today(offset = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return d.toISOString().split('T')[0];
}

function escHtml(s) {
  return (s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ── DERIVED DATA ──────────────────────────────────────────────────────────────

function getFiltered() {
  let list = [...state.tasks];
  if (state.view === 'active')    list = list.filter(t => !t.done);
  if (state.view === 'completed') list = list.filter(t => t.done);
  if (state.view === 'high')      list = list.filter(t => t.priority === 'high');
  if (state.view === 'today')     list = list.filter(t => t.due === today());
  if (state.filter !== 'all')     list = list.filter(t => t.priority === state.filter);
  if (state.search) {
    const q = state.search.toLowerCase();
    list = list.filter(t =>
      t.title.toLowerCase().includes(q) || (t.desc || '').toLowerCase().includes(q)
    );
  }
  const pOrder = { high: 0, medium: 1, low: 2 };
  list.sort((a, b) => {
    if (a.done !== b.done) return a.done ? 1 : -1;
    if (pOrder[a.priority] !== pOrder[b.priority]) return pOrder[a.priority] - pOrder[b.priority];
    if (a.due && b.due) return a.due.localeCompare(b.due);
    if (a.due) return -1;
    if (b.due) return 1;
    return b.created - a.created;
  });
  return list;
}

function counts() {
  return {
    all:       state.tasks.length,
    active:    state.tasks.filter(t => !t.done).length,
    completed: state.tasks.filter(t => t.done).length,
    high:      state.tasks.filter(t => t.priority === 'high' && !t.done).length,
    today:     state.tasks.filter(t => t.due === today()).length,
  };
}

function dueLabel(due) {
  if (!due) return null;
  const t = today(), tm = today(1);
  if (due < t)  return { label: 'Overdue',   cls: 'overdue' };
  if (due === t) return { label: 'Today',    cls: 'today'   };
  if (due === tm) return { label: 'Tomorrow', cls: 'soon'   };
  const d = new Date(due);
  return { label: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }), cls: '' };
}

// ── RENDER ────────────────────────────────────────────────────────────────────

function render() {
  renderNav();
  renderTopbar();
  renderFilters();
  renderTasks();
  renderStats();
}

function renderNav() {
  const c = counts();
  const views = [
    { id: 'all',       icon: '📋', label: 'All Tasks',     count: c.all       },
    { id: 'active',    icon: '⚡', label: 'Active',        count: c.active    },
    { id: 'completed', icon: '✅', label: 'Completed',     count: c.completed },
    { id: 'high',      icon: '🔴', label: 'High Priority', count: c.high      },
    { id: 'today',     icon: '📅', label: 'Due Today',     count: c.today     },
  ];
  document.getElementById('nav').innerHTML = views.map(v => `
    <div class="nav-item ${state.view === v.id ? 'active' : ''}" onclick="setView('${v.id}')">
      <span class="nav-icon">${v.icon}</span>
      <span>${v.label}</span>
      <span class="nav-count">${v.count}</span>
    </div>
  `).join('');
}

function renderTopbar() {
  const labels = {
    all: 'All Tasks', active: 'Active Tasks',
    completed: 'Completed', high: 'High Priority', today: 'Due Today'
  };
  document.getElementById('topbar-title').textContent = labels[state.view];
  const sub = getFiltered().length;
  document.getElementById('topbar-sub').textContent = `${sub} task${sub !== 1 ? 's' : ''}`;
}

function renderFilters() {
  const chips = [
    { id: 'all',    label: 'All Priorities' },
    { id: 'high',   label: '🔴 High'        },
    { id: 'medium', label: '🟡 Medium'      },
    { id: 'low',    label: '🟢 Low'         },
  ];
  document.getElementById('filters').innerHTML = chips.map(c =>
    `<button class="filter-chip ${state.filter === c.id ? 'active' : ''}" onclick="setFilter('${c.id}')">${c.label}</button>`
  ).join('');
}

function renderTasks() {
  const list = getFiltered();
  const el = document.getElementById('task-list');
  if (!list.length) {
    el.innerHTML = `<div class="empty-state">
      <div class="empty-icon">✨</div>
      <div class="empty-title">${state.search ? 'No tasks match your search' : 'Nothing here yet'}</div>
      <div class="empty-sub">${state.search ? 'Try a different keyword' : 'Add a task to get started'}</div>
    </div>`;
    return;
  }
  const active = list.filter(t => !t.done);
  const done   = list.filter(t =>  t.done);
  let html = '';
  if (active.length) html += active.map(taskCard).join('');
  if (done.length && state.view !== 'active') {
    html += `<div class="task-group-label">Completed</div>`;
    html += done.map(taskCard).join('');
  }
  el.innerHTML = html;
}

function taskCard(t) {
  const due = dueLabel(t.due);
  const dueHtml = due ? `<span class="due-date ${due.cls}">📅 ${due.label}</span>` : '';
  return `
  <div class="task-card ${t.done ? 'completed' : ''}">
    <div class="check-btn ${t.done ? 'done' : ''}" onclick="toggleDone('${t.id}')"></div>
    <div class="task-body">
      <div class="task-title">${escHtml(t.title)}</div>
      ${t.desc ? `<div class="task-desc">${escHtml(t.desc)}</div>` : ''}
      <div class="task-meta">
        <span class="badge badge-${t.priority}">${t.priority}</span>
        ${dueHtml}
      </div>
    </div>
    <div class="task-actions">
      <button class="icon-btn" onclick="openEdit('${t.id}')" title="Edit">✏️</button>
      <button class="icon-btn delete" onclick="confirmDelete('${t.id}')" title="Delete">🗑️</button>
    </div>
  </div>`;
}

function renderStats() {
  const total = state.tasks.length;
  const done  = state.tasks.filter(t => t.done).length;
  const pct   = total ? Math.round(done / total * 100) : 0;
  document.getElementById('sidebar-stats').innerHTML = `
    <div class="stat-row"><span>Progress</span><span class="stat-val">${done}/${total}</span></div>
    <div class="progress-bar"><div class="progress-fill" style="width:${pct}%"></div></div>
    <div class="stat-row" style="margin-top:10px;margin-bottom:0"><span>Completion</span><span class="stat-val">${pct}%</span></div>
  `;
}

// ── ACTIONS ───────────────────────────────────────────────────────────────────

function setView(v)   { state.view = v;   render(); }
function setFilter(f) { state.filter = f; render(); }

function toggleDone(id) {
  const t = state.tasks.find(t => t.id === id);
  if (t) { t.done = !t.done; saveTasks(); render(); }
}

function openAdd() {
  state.editId = null;
  document.getElementById('modal-title-text').textContent = 'New Task';
  document.getElementById('f-title').value    = '';
  document.getElementById('f-desc').value     = '';
  document.getElementById('f-priority').value = 'medium';
  document.getElementById('f-due').value      = '';
  document.getElementById('modal-overlay').classList.add('open');
  setTimeout(() => document.getElementById('f-title').focus(), 100);
}

function openEdit(id) {
  const t = state.tasks.find(t => t.id === id);
  if (!t) return;
  state.editId = id;
  document.getElementById('modal-title-text').textContent = 'Edit Task';
  document.getElementById('f-title').value    = t.title;
  document.getElementById('f-desc').value     = t.desc || '';
  document.getElementById('f-priority').value = t.priority;
  document.getElementById('f-due').value      = t.due || '';
  document.getElementById('modal-overlay').classList.add('open');
  setTimeout(() => document.getElementById('f-title').focus(), 100);
}

function closeModal() {
  document.getElementById('modal-overlay').classList.remove('open');
  state.editId = null;
}

function saveTask() {
  const title = document.getElementById('f-title').value.trim();
  if (!title) {
    document.getElementById('f-title').style.borderColor = 'var(--high)';
    return;
  }
  document.getElementById('f-title').style.borderColor = '';
  const task = {
    title,
    desc:     document.getElementById('f-desc').value.trim(),
    priority: document.getElementById('f-priority').value,
    due:      document.getElementById('f-due').value || null,
  };
  if (state.editId) {
    const idx = state.tasks.findIndex(t => t.id === state.editId);
    if (idx > -1) state.tasks[idx] = { ...state.tasks[idx], ...task };
  } else {
    state.tasks.unshift({ id: uid(), done: false, created: Date.now(), ...task });
  }
  saveTasks();
  closeModal();
  render();
}

function confirmDelete(id) {
  state.deleteId = id;
  document.getElementById('confirm-overlay').classList.add('open');
}

function doDelete() {
  state.tasks    = state.tasks.filter(t => t.id !== state.deleteId);
  state.deleteId = null;
  saveTasks();
  document.getElementById('confirm-overlay').classList.remove('open');
  render();
}

// ── EVENT LISTENERS ───────────────────────────────────────────────────────────

document.getElementById('add-btn').onclick       = openAdd;
document.getElementById('modal-close').onclick   = closeModal;
document.getElementById('modal-cancel').onclick  = closeModal;
document.getElementById('modal-save').onclick    = saveTask;

document.getElementById('confirm-cancel').onclick = () => {
  document.getElementById('confirm-overlay').classList.remove('open');
  state.deleteId = null;
};
document.getElementById('confirm-delete').onclick = doDelete;

document.getElementById('search-input').oninput = e => {
  state.search = e.target.value;
  render();
};

document.getElementById('modal-overlay').onclick = e => {
  if (e.target === document.getElementById('modal-overlay')) closeModal();
};

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    closeModal();
    document.getElementById('confirm-overlay').classList.remove('open');
  }
  if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') saveTask();
});

// ── INIT ──────────────────────────────────────────────────────────────────────

loadTasks();
render();
